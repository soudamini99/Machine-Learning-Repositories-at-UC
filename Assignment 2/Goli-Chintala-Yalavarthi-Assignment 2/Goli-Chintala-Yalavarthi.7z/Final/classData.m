%Function to calculate the class data values in the Regularization

function g = classData(x)
    for i=1:97
       class_data(i,1)= x (i, 4);    
    end
    g = class_data;
end
