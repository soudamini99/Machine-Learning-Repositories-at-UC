%Function to create the attribute data values in Regularization

function c = attribData(x)

for i=1:97
    for j=1:3
        p(i,j)= x(i, j);
    end
    c = p;
end